import numpy as np
import geopandas as gpd
from shapely.geometry import Point
import networkx as nx
from geopy.distance import geodesic
from geopy import Point as GeoPoint
from geopy.distance import distance as geopy_distance
import matplotlib.pyplot as plt
import requests, zipfile, io, os
from tqdm import tqdm
import matplotlib.cm as cm
import math
import pandas as pd

# Download Natural Earth shapefile if not present
url = "https://naciscdn.org/naturalearth/110m/cultural/ne_110m_admin_0_countries.zip"
extract_dir = "ne_110m_admin_0_countries"
if not os.path.exists(extract_dir):
    print("Downloading Natural Earth shapefile...")
    r = requests.get(url)
    with zipfile.ZipFile(io.BytesIO(r.content)) as zip_ref:
        zip_ref.extractall(extract_dir)
else:
    print("Natural Earth shapefile already downloaded.")

shp_path = os.path.join(extract_dir, "ne_110m_admin_0_countries.shp")
world = gpd.read_file(shp_path)
land = world.geometry.unary_union.buffer(0.07)  # ~7 km land buffer

# Define ports (lon, lat)
ports = {
    'Mumbai': (72.82, 18.96),
    'Chennai': (80.28, 13.08),
    'Kolkata': (88.36, 22.57),
    'Kochi': (76.28, 9.96),
    'Colombo': (79.85, 6.93),
    'Galle': (80.22, 6.03),
    'Trincomalee': (81.23, 8.57),
    'Hambantota': (81.12, 6.12)
}

offshore_bearings = {
    'Mumbai': 210,
    'Chennai': 180,
    'Kolkata': 195,
    'Kochi': 210,
    'Colombo': 210,
    'Galle': 210,
    'Trincomalee': 180,
    'Hambantota': 210
}
offshore_distance_m = 5000  # 5 km offshore

def shift_point_offshore(lon, lat, bearing_deg, distance_m):
    origin = GeoPoint(lat, lon)
    destination = geopy_distance(meters=distance_m).destination(origin, bearing_deg)
    return destination.longitude, destination.latitude

# Shift ports offshore
shifted_ports = {}
for port, (lon, lat) in ports.items():
    bearing = offshore_bearings.get(port, 180)
    shifted_lon, shifted_lat = shift_point_offshore(lon, lat, bearing, offshore_distance_m)
    shifted_ports[port] = (shifted_lon, shifted_lat)

# Create grid points
lon_vals = np.linspace(65, 95, 300)
lat_vals = np.linspace(3, 27, 240)
grid_points = [(lon, lat) for lat in lat_vals for lon in lon_vals]
grid_gdf = gpd.GeoDataFrame(geometry=[Point(lon, lat) for lon, lat in grid_points], crs='EPSG:4326')

# Filter water points
grid_gdf['on_land'] = grid_gdf.geometry.apply(lambda p: land.contains(p))
water_points = grid_gdf[~grid_gdf['on_land']].copy()

# Build graph
G = nx.Graph()
for idx, row in water_points.iterrows():
    G.add_node(idx, pos=(row.geometry.x, row.geometry.y))

sindex = water_points.sindex

def get_neighbors(point, max_dist_deg=0.15):
    possible_matches_index = list(sindex.intersection(point.buffer(max_dist_deg).bounds))
    possible_matches = water_points.iloc[possible_matches_index]
    neighbors = []
    for idx2, row2 in possible_matches.iterrows():
        if row2.geometry != point:
            dist = row2.geometry.distance(point)
            if dist <= max_dist_deg:
                neighbors.append(idx2)
    return neighbors

print("Building graph edges...")
for idx, row in tqdm(water_points.iterrows(), total=water_points.shape[0]):
    neighbors = get_neighbors(row.geometry)
    for nidx in neighbors:
        lon1, lat1 = row.geometry.x, row.geometry.y
        lon2, lat2 = water_points.loc[nidx].geometry.x, water_points.loc[nidx].geometry.y
        dist = geodesic((lat1, lon1), (lat2, lon2)).meters
        G.add_edge(idx, nidx, weight=dist)

def nearest_node_shifted(port_name):
    lon, lat = shifted_ports[port_name]
    point = Point(lon, lat)
    distances = water_points.geometry.distance(point)
    return distances.idxmin()

# Find shortest paths
paths = {}
for start_name in ports.keys():
    for end_name in ports.keys():
        if start_name != end_name:
            start_node = nearest_node_shifted(start_name)
            end_node = nearest_node_shifted(end_name)
            try:
                path = nx.shortest_path(G, start_node, end_node, weight='weight')
                paths[(start_name, end_name)] = path
            except nx.NetworkXNoPath:
                print(f"No water path between {start_name} and {end_name}")

# Extract route coordinates
route_points = {}
for (start_name, end_name), node_list in paths.items():
    coords = [(water_points.loc[n].geometry.y, water_points.loc[n].geometry.x) for n in node_list]
    route_points[(start_name, end_name)] = coords

# Offset lanes
def offset_lane(coords, offset_meters):
    lat_start, lon_start = coords[0]
    lat_end, lon_end = coords[-1]

    def bearing_rad(p1, p2):
        lat1, lon1 = math.radians(p1[0]), math.radians(p1[1])
        lat2, lon2 = math.radians(p2[0]), math.radians(p2[1])
        dLon = lon2 - lon1
        x = math.sin(dLon) * math.cos(lat2)
        y = math.cos(lat1)*math.sin(lat2) - math.sin(lat1)*math.cos(lat2)*math.cos(dLon)
        return math.atan2(x, y)

    brng = bearing_rad(coords[0], coords[-1])
    perp_brng = brng + math.pi / 2
    R = 6371000

    offset_coords = []
    n = len(coords)
    for i, (lat, lon) in enumerate(coords):
        scale = 1 - (i / (n - 1)) if n > 1 else 1
        offset_dist = offset_meters * scale
        dlat = (offset_dist / R) * (180 / math.pi) * math.cos(perp_brng)
        dlon = (offset_dist / R) * (180 / math.pi) * math.sin(perp_brng) / math.cos(math.radians(lat))
        offset_coords.append((lat + dlat, lon + dlon))
    return offset_coords

# Assign offsets
start_ports = list(set([key[0] for key in route_points.keys()]))
max_offset = 15000
lane_offsets = {}
for sp in start_ports:
    lanes_from_port = [k for k in route_points.keys() if k[0] == sp]
    n = len(lanes_from_port)
    if n == 1:
        lane_offsets[lanes_from_port[0]] = 0
        continue
    offsets = np.linspace(-max_offset, max_offset, n)
    for lane, offset in zip(lanes_from_port, offsets):
        lane_offsets[lane] = offset

# SAVE AIS POINTS TO CSV (WATER-ONLY)
all_points = []
for lane_key, coords in route_points.items():
    offset_m = lane_offsets.get(lane_key, 0)
    coords_offset = offset_lane(coords, offset_m) if offset_m != 0 else coords
    for lat, lon in coords_offset:
        pt = Point(lon, lat)
        if not land.contains(pt):  # ensure point is on water
            all_points.append({
                'latitude': lat,
                'longitude': lon,
                'route': f"{lane_key[0]} to {lane_key[1]}"
            })

df = pd.DataFrame(all_points)
output_csv = "ais_ship_points_with_offsets.csv"
df.to_csv(output_csv, index=False)
print(f"✅ Saved AIS ship points (water-only) to {output_csv}")

# PLOTTING
fig, ax = plt.subplots(figsize=(14, 10))
world.plot(ax=ax, color='lightgray', edgecolor='black')

num_routes = len(route_points)
colors = cm.get_cmap('tab20', num_routes)

for idx, (lane_key, coords) in enumerate(route_points.items()):
    offset_m = lane_offsets.get(lane_key, 0)
    coords_offset = offset_lane(coords, offset_m) if offset_m != 0 else coords

    # Keep only water points for plotting
    water_coords = [(lat, lon) for lat, lon in coords_offset if not land.contains(Point(lon, lat))]
    lats = [lat for lat, lon in water_coords]
    lons = [lon for lat, lon in water_coords]

    ax.scatter(lons, lats, s=10, alpha=0.7, label=f"{lane_key[0]} to {lane_key[1]}", color=colors(idx))

# Plot ports
for name, (lon, lat) in ports.items():
    ax.plot(lon, lat, 'ro')
    ax.text(lon + 0.15, lat, name, fontsize=9)

ax.set_xlim(65, 95)
ax.set_ylim(3, 27)
ax.set_title("AIS Ship Points (Water-Only) with Lateral Gaps Between Routes")
ax.legend(fontsize='small', bbox_to_anchor=(1.05, 1), loc='upper left')
plt.tight_layout()
plt.show()
